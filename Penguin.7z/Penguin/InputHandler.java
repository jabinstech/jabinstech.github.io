import java.util.Scanner;
import java.util.ArrayList;

public class InputHandler
{
    public static void main()
    {
        Scanner kb = new Scanner(System.in);
        
        ArrayList<Penguin> herd = new ArrayList<Penguin>();
        ArrayList<String> colors = new ArrayList<String>();
        ArrayList<String> commands = new ArrayList<String>();
        colors.add("red");
        colors.add("orange");
        colors.add("yellow");
        colors.add("green");
        colors.add("blue");
        colors.add("purple");
        colors.add("brown");
        colors.add("white");
        commands.add("help");
        commands.add("info");
        commands.add("penguins");
        commands.add("add");
        commands.add("age");
        commands.add("play");
        commands.add("shop");
        System.out.println("Penguin name?");
        String makingName = kb.nextLine();
        System.out.println("Penguin color?");
        String color = "undefined";
        while (!colors.contains(color))
        {
            color = kb.nextLine();
        }
        Penguin ONE = new Penguin(makingName, 500, color, 0, 0);
        herd.add(ONE);
        System.out.println("Penguin created with ID \"ONE\". Check on which penguins you have with the \"penguins\" command.");
        while (true)
        {
            System.out.println("Welcome to Club Penguin Simulator! Type \"help\" for a list of commands.");
            String command = "undefined";
            if (commands.contains(command))
            {
                if (command == "help")
                {
                    System.out.println(commands);
                }
                if (command == "info")
                {
                    System.out.println("Which penguin would you like to view? (Enter BACK to cancel.)");
                    String infoView = "undefined";
                    while (!(herd.contains(infoView) || infoView == "back"))
                    {
                        infoView = kb.nextLine();
                    }
                    if (infoView == "back")
                    {
                        
                    }
                }
            }
        }
    }
}