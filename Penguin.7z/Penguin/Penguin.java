import java.util.ArrayList;
import java.util.Scanner;

public class Penguin
{
    String name;
    int coins;
    String color;
    int age;
    int stamps;
    
    public Penguin(String n, int c, String o, int a, int s)
    {
        name = n;
        coins = c;
        color = o;
        age = a;
        stamps = s;

        System.err.println("[InputHandler] Created penguin named " + n + ", with " + c + " coins, colored " + o + ", " + a + " days old, with " + s + " stamps.");
    }
    
    public Penguin()
    {
        ArrayList<String> defaultNames = new ArrayList<String>();
        defaultNames.clear();
        defaultNames.add("Gregory");
        defaultNames.add("Walter");
        defaultNames.add("Bartholomew");
        defaultNames.add("Theodore");
        defaultNames.add("Gertrude");
        defaultNames.add("Wanda");
        defaultNames.add("Inky Pinky");
        
        name = defaultNames.get(0 + (int)(Math.random() * ((6 - 0) + 1)));
        coins = 500;
        color = "Red";
        age = 0;
        stamps = 0;
        System.err.println("[InputHandler] Created default penguin with name " + name + ".");
    }

    public String toString()
    {
        return "Penguin named \"" + name + "\" has " + coins + " coins, and " + stamps + " stamps. It is " + age + " days old, and is colored " + color + ".";
    }
    
    public String returnName()
    {
        return name;
    }
}