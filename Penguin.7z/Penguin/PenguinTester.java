import java.util.*;

public class PenguinTester
{
    public static void newDefault()
    {
        
    }
    public static void twoNewDefaultAndPrintStats()
    {
        Scanner kb = new Scanner(System.in);
        ArrayList<Penguin> herd = new ArrayList<Penguin>();
        
        
        while (true)
        {
            Penguin one = new Penguin();
            Penguin two = new Penguin();
        }
    }
}  